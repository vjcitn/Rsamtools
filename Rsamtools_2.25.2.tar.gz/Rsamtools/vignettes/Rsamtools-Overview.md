---
title: "An Introduction to Rsamtools"
author:
- name: "Martin Morgan"
- name: "Samuel Busayo"
  affiliation: "Vignette translation from Sweave to Rmarkdown / HTML"
date: "Modified: 18 March, 2010. Compiled:September 01 2025"
package: Rsamtools
vignette: >
  %\VignetteIndexEntry{An Introduction to Rsamtools}
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteEncoding{UTF-8}
output:
  BiocStyle::html_document:
    number_sections: true
    toc: true
    toc_depth: 4
---






























































